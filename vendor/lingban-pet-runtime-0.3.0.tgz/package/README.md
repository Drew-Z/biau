# @lingban/pet-runtime 0.3.0

Small ESM runtime shared by Pet Studio review, standalone web pets and host adapters. `core.js` has no browser dependencies; `renderer` uses Pixi 8; `widget` loads a same-origin public bundle. React, Next, Electron, chat services and creation APIs remain in their hosts.

```js
import {mountPet} from '@lingban/pet-runtime/widget';
const abort = new AbortController();
const pet = await mountPet(element, '/pets/leaf/pet.json', {signal: abort.signal});
pet.setActivity('working');
pet.greet();
// On unmount:
abort.abort();
pet.destroy();
```

The host must have nonzero width and height and provide the keyboard-accessible interactive control. Activities are idle, thinking, working, needsInput, review, ready, blocked and sleepy. New activity interrupts the current action; repeated greets coalesce. Reduced motion displays the first frame of the selected action without continuous rendering; explicit state changes remain available.

| Activity | Assistant package action | Legacy three-action package |
| --- | --- | --- |
| idle / sleepy | idle / sleepy | idle / sleepy |
| thinking / working | thinking / working | idle |
| needsInput | waiting | idle |
| review | review | idle |
| blocked | failed | idle |
| ready | happy once, then review | happy once, then idle |

Explicit greet plays happy once and returns to the current activity. Ordinary actions retain their own loop flag; a non-looping failed action holds its final pose. State labels do not create missing artwork.

Playback preserves nonuniform timing, single-shot completion, source-frame versus legacy physical-atlas indexing and reviewed-anchor registration. Browser visibility and intersection suspend the clock. Each renderer owns textures/object URLs and cleans up listeners, observers and animation frames. Caller abort plus destroy must be paired with the host lifecycle.

Legacy public bundles keep schemaVersion=1 with idle/happy/sleepy. New bundles use schemaVersion=2, actionSet=assistant-v1 and exactly eight actions: idle, thinking, working, waiting, review, happy, failed, sleepy. Each new action has a 4/5/6/8-source timeline. Representation remains sprite2d. Each bundle contains only pet.json and its declared action PNGs, with SHA-256 and bounded geometry/timeline metadata.

Files are same-origin with redirects disabled; image bytes, dimensions and hashes are checked before decoding. Use `scripts/export_web_pet.py` with a reviewed source archive hash. It projects legacy official ZIP v1/v2 into public v1, or official ZIP v3 with actionSet=assistant-v1 into public v2. Missing actions fail instead of silently exporting a three-action subset. Never publish authoring manifests. Asset licenses are unspecified until separately documented.

## Agent lifecycle projection

```js
import {createActivityState, reduceActivity, selectActivity} from '@lingban/pet-runtime/activity';
let state = createActivityState();
state = reduceActivity(state, {type: 'started', sessionId: 'blog:research', runId: 'run-1', sequence: 1, label: 'Research'});
state = reduceActivity(state, {type: 'completed', sessionId: 'blog:research', runId: 'run-1', sequence: 2, outcome: 'success'});
const summary = selectActivity(state); // ready, one unread result
```

The host supplies started, thinking, working, review, needsInput, completed, failed, cancelled and read events. Every event carries a session ID, run ID and producer-assigned sequence increasing per session **across runs**; assigning a sequence only when a delayed callback arrives does not establish ordering. Namespace session IDs across providers. Only started creates/replaces a run. Duplicate, stale, wrong-run and late terminal callbacks are ignored. A completion's outcome is required: success becomes ready; partial/uncertain/degraded become review and never celebrate. A matching read clears completion attention. Failed tasks persist until a new run; cancellation never celebrates.

Each session stores only its latest run. A new `started` event replaces the previous run, including its unread completion; this is an activity projection, not a historical notification inbox. Hosts that retain past unread results must keep that history separately.

Priority is needsInput > blocked > review > ready > working/thinking > idle; ties use locally applied event order. Background sessions participate. Counts include review and thinking. This changes the 0.2.0 projection of limited results from needsInput to review; consumers must update status labels when upgrading. `completionKey` identifies successful selected results for bounded one-shot feedback deduplication independently of unread visibility. Hosts should apply review as the ready base state, then call greet once per unseen key; this prevents priority changes replaying the same celebration. The demo follows this pattern.

No hooks, polling, credentials, automatic retries, chat text or model calls live in this module. State is in-memory, accepts at most 64 session identities and rejects overflow explicitly; host persistence, reconnection and session retirement are separate integration work.

`npm test --workspace @lingban/pet-runtime` runs pure clock/activity tests. Browser and archive validation live in the root repository. Distribute locally with `npm pack --workspace @lingban/pet-runtime`; pin the resulting tarball in the consumer. Blog-semi's actual lifecycle adapter is delivered and verified in the host; updating this package alone does not connect real assistant events. No forked runtime source is copied into hosts.

The repository's Python `petstudio.codex_pet` command inspects and packages independently reviewed Codex v2 atlases, a separate contract from public web v2; it does not reuse this widget inside Codex. Existing accepted characters still have three actions. Eight-state contract tests use synthetic fixtures, not new accepted artwork. The backend generation/export producer is being extended separately; skeletal bodies, IK and 3D remain future work.
