// Host-owned lifecycle events; no polling, model calls, clocks, or private text.
const TYPES = new Set(["started", "thinking", "working", "review", "needsInput", "completed", "failed", "cancelled", "read"]);
const OUTCOMES = new Set(["success", "partial", "uncertain", "degraded"]);
const PRIORITY = {needsInput: 5, blocked: 4, review: 3, ready: 2, working: 1, thinking: 1};
const terminal = status => ["completed", "failed", "cancelled"].includes(status);
const identifier = value => typeof value === "string" && value.length > 0 && value.length <= 128 && !/[\u0000-\u001f]/.test(value);

export function createActivityState() {return {revision: 0, sessions: []};}

/** sequence must increase per session, across runs, on the host event stream. */
export function reduceActivity(state, event) {
  if (!event || !TYPES.has(event.type) || !identifier(event.sessionId) || !identifier(event.runId)
      || !Number.isSafeInteger(event.sequence) || event.sequence < 0
      || (event.type === "started" && event.label !== undefined && (!identifier(event.label)))
      || (event.type === "completed" && !OUTCOMES.has(event.outcome))) throw Error("Invalid pet activity event");
  const index = state.sessions.findIndex(item => item.sessionId === event.sessionId);
  const previous = state.sessions[index];
  if (previous && event.sequence <= previous.sequence) return state;
  if (event.type !== "started" && (!previous || previous.runId !== event.runId)) return state;
  // A duplicate start cannot resurrect a completed/cancelled run.
  if (event.type === "started" && previous?.runId === event.runId) return state;
  if (event.type !== "started" && terminal(previous.status)
      && !(event.type === "read" && previous.status === "completed" && previous.unread)) return state;
  if (event.type === "read" && previous.status !== "completed") return state;
  if (!previous && state.sessions.length >= 64) throw Error("Pet activity session limit reached");
  const revision = state.revision + 1;
  const item = event.type === "started"
    ? {sessionId: event.sessionId, runId: event.runId, label: event.label ?? event.sessionId, status: "working", unread: false, outcome: null}
    : {...previous};
  item.sequence = event.sequence;
  item.order = revision;
  if (event.type === "read") item.unread = false;
  else if (event.type !== "started") {
    item.status = event.type;
    item.unread = event.type === "completed";
    item.outcome = event.type === "completed" ? event.outcome : null;
  }
  const sessions = state.sessions.slice();
  if (index < 0) sessions.push(item); else sessions[index] = item;
  return {revision, sessions};
}

function activityOf(session) {
  if (session.status === "needsInput") return "needsInput";
  if (session.status === "failed") return "blocked";
  if (session.status === "completed" && session.unread) return session.outcome === "success" ? "ready" : "review";
  return ["thinking", "working", "review"].includes(session.status) ? session.status : "idle";
}

export function selectActivity(state) {
  const counts = {needsInput: 0, blocked: 0, review: 0, ready: 0, working: 0, thinking: 0};
  const items = state.sessions.map(session => ({...session, activity: activityOf(session)}))
    .filter(item => item.activity !== "idle")
    .sort((a, b) => PRIORITY[b.activity] - PRIORITY[a.activity] || b.order - a.order);
  for (const item of items) counts[item.activity]++;
  const selected = items[0];
  return {activity: selected?.activity ?? "idle", sessionId: selected?.sessionId ?? null,
    runId: selected?.runId ?? null, counts, items,
    // Hosts can deduplicate one-shot feedback independently of unread visibility.
    completionKey: selected?.activity === "ready" ? JSON.stringify([selected.sessionId, selected.runId]) : null};
}
