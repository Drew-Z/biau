import type {Activity} from "./core.js";
export type Outcome = "success" | "partial" | "uncertain" | "degraded";
export type TaskStatus = "thinking" | "working" | "review" | "needsInput" | "completed" | "failed" | "cancelled";
type EventIdentity = {sessionId: string; runId: string; sequence: number};
export type ActivityEvent = EventIdentity & (
  {type: "started"; label?: string} | {type: "completed"; outcome: Outcome} |
  {type: "thinking" | "working" | "review" | "needsInput" | "failed" | "cancelled" | "read"}
);
export type TaskActivity = {sessionId: string; runId: string; label: string; sequence: number;
  order: number; status: TaskStatus; unread: boolean; outcome: Outcome | null};
export type ActivityState = {revision: number; sessions: TaskActivity[]};
export type ActivitySummary = {activity: Activity; sessionId: string | null; runId: string | null;
  counts: Record<"needsInput" | "blocked" | "review" | "ready" | "working" | "thinking", number>;
  items: (TaskActivity & {activity: Activity})[]; completionKey: string | null};
export function createActivityState(): ActivityState;
export function reduceActivity(state: ActivityState, event: ActivityEvent): ActivityState;
export function selectActivity(state: ActivityState): ActivitySummary;
