import {Application, Texture, Sprite, Rectangle, Graphics} from "pixi.js";
import {actionDurationMs, displayedAnchor, frameOffset, playbackAt, readBytes, validateDrawable} from "./core.js";

export async function createSpritePlayer(host, options = {}) {
  const app = new Application();
  try {await app.init({resizeTo: host, backgroundAlpha: 0, antialias: true, resolution: Math.min(devicePixelRatio || 1, 2), autoDensity: true, autoStart: false});}
  catch (error) {try {app.destroy(true);} catch {} throw error;}
  if (options.signal?.aborted) {app.destroy(true); throw new DOMException("Aborted", "AbortError");}
  host.appendChild(app.canvas);
  const sprite = new Sprite(); sprite.anchor.set(0.5); sprite.eventMode = "static";
  if (options.onInteract) {sprite.cursor = "pointer"; sprite.on("pointertap", options.onInteract);}
  const guides = new Graphics(); app.stage.addChild(sprite, guides);
  let destroyed = false, asset, textures = [], source, imageURL, request;
  let time = 0, previous = 0, frame = 0, speed = 1, playing = false, completed = false, loop, anchors = false, lastEntry = -1;
  const motion = matchMedia("(prefers-reduced-motion: reduce)");
  let inView = true;
  const active = () => !destroyed && asset && playing && !document.hidden && !motion.matches && inView;
  const stopFrame = () => {if (frame) cancelAnimationFrame(frame); frame = 0; previous = 0;};
  const draw = (force = false) => {
    if (destroyed || !asset) return;
    const sample = playbackAt(asset, motion.matches ? 0 : time, loop);
    if (sample.entryIndex === lastEntry && !force) return;
    lastEntry = sample.entryIndex; sprite.texture = textures[sample.sourceFrame];
    const m = asset.meta; sprite.scale.set(Math.min(app.screen.width, app.screen.height) * 0.9 / Math.max(m.frameWidth, m.frameHeight));
    const offset = frameOffset(asset, sample.entryIndex);
    sprite.position.set(app.screen.width / 2 + offset.x * m.frameWidth * sprite.scale.x, app.screen.height / 2 + offset.y * m.frameHeight * sprite.scale.y);
    host.dataset.entry = String(sample.entryIndex); host.dataset.sourceFrame = String(sample.sourceFrame);
    host.dataset.durationMs = String(actionDurationMs(asset)); host.dataset.playback = completed ? "completed" : playing ? "playing" : "paused";
    guides.clear();
    for (const kind of ["body", "support"]) {
      const point = anchors ? displayedAnchor(asset, sample.entryIndex, kind) : null;
      if (!point) {delete host.dataset[`${kind}Anchor`]; continue;}
      guides.circle(app.screen.width / 2 + (point.x - 0.5) * m.frameWidth * sprite.scale.x, app.screen.height / 2 + (point.y - 0.5) * m.frameHeight * sprite.scale.y, 5)
        .fill(kind === "body" ? 0xb42318 : 0x175cd3).stroke({width: 1, color: 0xffffff});
      host.dataset[`${kind}Anchor`] = `${point.x.toFixed(6)},${point.y.toFixed(6)}`;
    }
    app.render();
  };
  const schedule = () => {if (active() && !frame) frame = requestAnimationFrame(tick);};
  const tick = now => {
    frame = 0; if (!active()) {previous = 0; return;}
    if (previous) time += Math.max(0, now - previous) * speed;
    previous = now;
    const sample = playbackAt(asset, time, loop);
    if (sample.completed && !completed) {
      completed = true; playing = false; previous = 0; draw(true); options.onComplete?.();
    } else {draw(); schedule();}
  };
  const visibility = () => {stopFrame(); draw(true); schedule();};
  document.addEventListener("visibilitychange", visibility); motion.addEventListener("change", visibility);
  const resize = new ResizeObserver(() => {if (!destroyed) {app.resize(); draw(true);}}); resize.observe(host);
  const observer = typeof IntersectionObserver === "undefined" ? null : new IntersectionObserver(([entry]) => {inView = entry.isIntersecting; visibility();}); observer?.observe(host);
  function release() {textures.forEach(t => t.destroy(false)); textures = []; source?.destroy(true); source = undefined; if (imageURL) URL.revokeObjectURL(imageURL); imageURL = undefined;}
  const player = {
    async setAsset(next) {
      validateDrawable(next); if (destroyed) throw Error("Player destroyed");
      request?.abort(); const pending = new AbortController(); request = pending;
      let url;
      try {
        const bytes = await readBytes(next.url, 33554432, pending.signal);
        const view = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
        if (bytes.length < 24 || view.getUint32(0) !== 0x89504e47 || view.getUint32(4) !== 0x0d0a1a0a || view.getUint32(12) !== 0x49484452
            || view.getUint32(16) !== next.meta.frameCount * next.meta.frameWidth || view.getUint32(20) !== next.meta.frameHeight) throw Error("PNG dimensions do not match manifest");
        if (next.sha256) {
          const sha = [...new Uint8Array(await crypto.subtle.digest("SHA-256", bytes))].map(b => b.toString(16).padStart(2, "0")).join("");
          if (sha !== next.sha256) throw Error("Sprite hash mismatch");
        }
        url = URL.createObjectURL(new Blob([bytes], {type: "image/png"}));
        const image = new Image(); image.src = url; await image.decode();
        if (destroyed || pending.signal.aborted) throw new DOMException("Aborted", "AbortError");
        const texture = Texture.from(image, true);
        const newFrames = Array.from({length: next.meta.frameCount}, (_, i) => new Texture({source: texture.source, frame: new Rectangle(i * next.meta.frameWidth, 0, next.meta.frameWidth, next.meta.frameHeight)}));
        stopFrame(); release(); source = texture; textures = newFrames; imageURL = url; url = undefined;
        asset = next; time = 0; completed = false; lastEntry = -1; draw(true); schedule();
      } finally {if (url) URL.revokeObjectURL(url);}
    },
    play(restart = false) {if (destroyed) return; if (restart || completed) time = 0; completed = false; playing = true; draw(true); schedule();},
    pause() {playing = false; stopFrame(); draw(true);},
    seek(value) {if (!asset || destroyed) return; playing = false; stopFrame(); time = Number.isFinite(value) ? Math.max(0, value) : 0; completed = playbackAt(asset, time, loop).completed; draw(true);},
    setSpeed(value) {if (!Number.isFinite(value) || value <= 0 || value > 8) throw Error("Invalid playback speed"); speed = value;},
    setLoop(value) {loop = value;},
    setAnchors(value) {anchors = value; draw(true);},
    destroy() {
      if (destroyed) return; destroyed = true; request?.abort(); stopFrame(); resize.disconnect(); observer?.disconnect();
      document.removeEventListener("visibilitychange", visibility); motion.removeEventListener("change", visibility); options.signal?.removeEventListener("abort", player.destroy);
      app.destroy(true, {children: true, texture: false, textureSource: false}); release();
    },
  };
  options.signal?.addEventListener("abort", player.destroy, {once: true});
  return player;
}
