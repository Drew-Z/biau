import {loadPet, createController} from "./core.js";
import {createSpritePlayer} from "./renderer.js";

export async function mountPet(host, manifestUrl, options = {}) {
  const cancel = new AbortController();
  const abort = () => cancel.abort(); options.signal?.addEventListener("abort", abort, {once: true});
  if (options.signal?.aborted) cancel.abort();
  let player, disposed = false, generation = 0;
  let controller;
  async function change(action, once) {
    const version = ++generation;
    try {
      player.pause(); await player.setAsset(pet.actions[action]);
      if (disposed || cancel.signal.aborted || version !== generation) return;
      host.dataset.action = action; host.dataset.petState = "ready";
      player.setLoop(once ? false : pet.actions[action].meta.motion?.loop ?? pet.actions[action].meta.loop ?? true);
      player.play(true);
    } catch (error) {
      if (disposed || version !== generation || error?.name === "AbortError") return;
      host.dataset.petState = "error"; player.pause();
    }
  }
  let pet;
  try {
    host.dataset.petState = "loading";
    pet = await loadPet(manifestUrl, cancel.signal);
    controller = createController((action, once) => {void change(action, once);}, Object.keys(pet.actions));
    player = await createSpritePlayer(host, {signal: cancel.signal, onComplete: () => controller.complete()});
    await player.setAsset(pet.actions.idle);
    cancel.signal.throwIfAborted();
    player.play(); host.dataset.action = "idle"; host.dataset.petState = "ready";
  } catch (error) {
    player?.destroy(); controller?.destroy(); cancel.abort(); options.signal?.removeEventListener("abort", abort); host.dataset.petState = "error"; throw error;
  }
  return {
    setActivity(value) {if (!disposed && !cancel.signal.aborted) {controller.setActivity(value); host.dataset.activity = value;}},
    greet() {if (!disposed && !cancel.signal.aborted) controller.greet();},
    destroy() {if (disposed) return; disposed = true; generation++; controller.destroy(); player.destroy(); cancel.abort(); options.signal?.removeEventListener("abort", abort); host.dataset.petState = "destroyed";},
  };
}
