import type {Activity} from "./core.js";
export function mountPet(host: HTMLElement, manifestUrl: string, options?: {signal?: AbortSignal}): Promise<{
  setActivity(activity: Activity): void; greet(): void; destroy(): void;
}>;
