// Framework-neutral clock and registration rules shared by review and embedded pets.
export function playbackEntries(asset) {
  return asset.meta.motion?.entries ?? Array.from({length: asset.meta.frameCount}, (_, sourceFrame) => ({sourceFrame, durationMs: 1000 / (asset.meta.fps ?? 6)}));
}
export function actionDurationMs(asset) {return playbackEntries(asset).reduce((sum, entry) => sum + entry.durationMs, 0);}
export function frameOffset(asset, entryIndex) {
  const motion = asset.meta.motion;
  if (!motion) return {x: 0, y: 0};
  const root = [...motion.root].sort((a, b) => a.entryIndex - b.entryIndex).filter(r => r.entryIndex <= entryIndex).at(-1) ?? {x: 0, y: 0};
  if (motion.registration === "preserve" || !["user_annotated", "user_confirmed_agent"].includes(asset.meta.motionReview?.anchors ?? "")) return {x: root.x, y: root.y};
  const sourceFrame = motion.entries[entryIndex].sourceFrame;
  const support = motion.registration === "support" && motion.contacts.includes(entryIndex);
  const referenceFrame = motion.entries[support ? Math.min(...motion.contacts) : 0].sourceFrame;
  const point = frame => {
    const anchor = motion.anchors.find(a => a.sourceFrame === frame);
    const p = support ? anchor?.support : anchor?.body;
    const t = asset.meta.processing?.transforms?.[frame] ?? {scale: 1, x: 0, y: 0};
    return p ? {x: p.x * t.scale + t.x / asset.meta.frameWidth, y: p.y * t.scale + t.y / asset.meta.frameHeight} : null;
  };
  const current = point(sourceFrame), reference = point(referenceFrame);
  return current && reference ? {x: reference.x - current.x + root.x, y: reference.y - current.y + root.y} : {x: root.x, y: root.y};
}
export function playbackAt(asset, elapsedMs, loopOverride) {
  const entries = playbackEntries(asset), duration = actionDurationMs(asset);
  const loop = loopOverride ?? asset.meta.motion?.loop ?? asset.meta.loop !== false;
  const elapsed = Number.isFinite(elapsedMs) ? Math.max(0, elapsedMs) : 0;
  const completed = !loop && elapsed >= duration;
  let local = loop ? elapsed % duration : Math.min(elapsed, duration);
  let entryIndex = entries.length - 1;
  if (!completed) for (let i = 0; i < entries.length; i++) {
    if (local < entries[i].durationMs) {entryIndex = i; break;}
    local -= entries[i].durationMs;
  }
  const sourceFrame = entries[entryIndex].sourceFrame;
  return {entryIndex, sourceFrame, logicalSourceFrame: asset.meta.motion ? sourceFrame : asset.meta.processing?.frameOrder?.[entryIndex] ?? sourceFrame, completed};
}
export function displayedAnchor(asset, entryIndex, kind) {
  const motion = asset.meta.motion;
  if (!motion) return null;
  const sourceFrame = motion.entries[entryIndex].sourceFrame;
  const point = motion.anchors.find(anchor => anchor.sourceFrame === sourceFrame)?.[kind];
  if (!point) return null;
  const transform = asset.meta.processing?.transforms?.[sourceFrame] ?? {scale: 1, x: 0, y: 0};
  const offset = frameOffset(asset, entryIndex);
  return {x: point.x * transform.scale + transform.x / asset.meta.frameWidth + offset.x,
    y: point.y * transform.scale + transform.y / asset.meta.frameHeight + offset.y};
}
const integer = (n, min, max) => Number.isInteger(n) && n >= min && n <= max;
const finite = (n, min, max) => Number.isFinite(n) && n >= min && n <= max;
const array = (v, max) => Array.isArray(v) && v.length <= max;
const point = p => p && finite(p.x, -10, 10) && finite(p.y, -10, 10);
export function validateDrawable(value) {
  const m = value?.meta;
  if (!m || !integer(m.frameCount, 1, 256) || !integer(m.frameWidth, 1, 2048) || !integer(m.frameHeight, 1, 2048)
      || m.frameCount * m.frameWidth > 16384 || m.frameCount * m.frameWidth * m.frameHeight > 16777216) throw Error("Invalid sprite dimensions");
  if (m.fps !== undefined && !finite(m.fps, 0.1, 120)) throw Error("Invalid frame rate");
  if (m.loop !== undefined && typeof m.loop !== "boolean") throw Error("Invalid loop flag");
  if (m.motion) {
    const t = m.motion;
    if (t.version !== 1 || t.sourceFrameCount !== m.frameCount || typeof t.loop !== "boolean" || !["preserve", "body", "support"].includes(t.registration)
        || !array(t.entries, 1024) || !t.entries.length || !array(t.root, 1024) || !array(t.anchors, 256) || !array(t.contacts, 1024)) throw Error("Invalid timeline");
    if (t.entries.some(e => !integer(e.sourceFrame, 0, m.frameCount - 1) || !finite(e.durationMs, 1, 60000))
        || t.root.some(p => !integer(p.entryIndex, 0, t.entries.length - 1) || !point(p))
        || t.contacts.some(i => !integer(i, 0, t.entries.length - 1))
        || t.anchors.some(a => !integer(a.sourceFrame, 0, m.frameCount - 1) || !point(a.body) || (a.support && !point(a.support)))) throw Error("Invalid timeline entries");
  }
  const p = m.processing;
  if (p?.transforms && (!array(p.transforms, 256) || p.transforms.some(t => !finite(t.scale, 0.01, 10) || !finite(t.x, -16384, 16384) || !finite(t.y, -16384, 16384)))) throw Error("Invalid transforms");
  if (!m.motion && p?.frameOrder && (!array(p.frameOrder, 256) || p.frameOrder.length !== m.frameCount || p.frameOrder.some(i => !integer(i, 0, 255)))) throw Error("Invalid legacy frame order");
  if (actionDurationMs(value) > 600000) throw Error("Timeline too long");
  return value;
}
export const CORE_ACTIONS = Object.freeze(["idle", "happy", "sleepy"]);
export const ASSISTANT_ACTIONS = Object.freeze(["idle", "thinking", "working", "waiting", "review", "happy", "failed", "sleepy"]);
export function validatePet(value) {
  const required = value?.schemaVersion === 1 ? CORE_ACTIONS
    : value?.schemaVersion === 2 && value.actionSet === "assistant-v1" ? ASSISTANT_ACTIONS : null;
  if (!required || value.representation !== "sprite2d" || typeof value.name !== "string" || !value.name.trim() || value.name.length > 80
      || !value.actions || Object.keys(value.actions).sort().join() !== [...required].sort().join()) throw Error("Unsupported pet manifest");
  for (const [id, a] of Object.entries(value.actions)) {
    validateDrawable(a);
    if (value.schemaVersion === 2 && (![4, 5, 6, 8].includes(a.meta.frameCount) || !a.meta.motion)) throw Error("Assistant actions require a 4/5/6/8-source timeline");
    if (a.file !== `${id}.png` || !/^[a-f0-9]{64}$/.test(a.sha256)) throw Error("Invalid pet resource");
  }
  return value;
}
export async function readBytes(url, maxBytes, signal) {
  const response = await fetch(url, {signal, credentials: "same-origin", redirect: "error"});
  if (!response.ok || Number(response.headers.get("content-length")) > maxBytes) throw Error("Pet resource unavailable or too large");
  const reader = response.body?.getReader();
  if (!reader) throw Error("Missing resource body");
  const chunks = []; let size = 0;
  try {
    while (true) {
      const {done, value} = await reader.read(); if (done) break;
      size += value.length; if (size > maxBytes) throw Error("Pet resource too large"); chunks.push(value);
    }
  } catch (error) {await reader.cancel().catch(() => {}); throw error;} finally {reader.releaseLock();}
  const bytes = new Uint8Array(size); let offset = 0;
  for (const chunk of chunks) {bytes.set(chunk, offset); offset += chunk.length;}
  return bytes;
}
export async function loadPet(url, signal) {
  const base = new URL(url, globalThis.location?.href);
  if (!["https:", "http:"].includes(base.protocol) || base.username || base.password || (globalThis.location && base.origin !== location.origin)) throw Error("Pet must use same-origin resources");
  const pet = validatePet(JSON.parse(new TextDecoder("utf-8", {fatal: true}).decode(await readBytes(base.href, 262144, signal))));
  return {...pet, actions: Object.fromEntries(Object.entries(pet.actions).map(([id, a]) => [id, {...a, id, kind: "action", url: new URL(a.file, base).href}]))};
}
const ACTIVITY_ACTIONS = Object.freeze({idle: "idle", thinking: "thinking", working: "working", needsInput: "waiting", review: "review", ready: "review", blocked: "failed", sleepy: "sleepy"});
export function chooseAction(activity, availableActions = CORE_ACTIONS) {
  if (!Object.hasOwn(ACTIVITY_ACTIONS, activity)) throw Error("Unknown pet activity");
  const action = ACTIVITY_ACTIONS[activity];
  return availableActions.includes(action) ? action : "idle";
}
export function createController(onChange, availableActions = CORE_ACTIONS) {
  const available = [...availableActions];
  if (!CORE_ACTIONS.every(action => available.includes(action)) || available.some(action => !ASSISTANT_ACTIONS.includes(action))) throw Error("Unsupported controller actions");
  let activity = "idle", once = false, destroyed = false;
  return {
    setActivity(next) {
      if (destroyed || next === activity) return;
      chooseAction(next, available);
      activity = next; once = next === "ready"; onChange(once ? "happy" : chooseAction(next, available), once);
    },
    greet() {if (destroyed || once) return; once = true; onChange("happy", true);},
    complete() {if (destroyed || !once) return; once = false; onChange(chooseAction(activity, available), false);},
    destroy() {destroyed = true;},
  };
}
