import type {Drawable} from "./core.js";
export type SpritePlayer = {
  setAsset(asset: Drawable): Promise<void>; play(restart?: boolean): void; pause(): void;
  seek(timeMs: number): void; setSpeed(speed: number): void; setLoop(loop?: boolean): void;
  setAnchors(show: boolean): void; destroy(): void;
};
export function createSpritePlayer(host: HTMLElement, options?: {
  onComplete?: () => void; onInteract?: () => void; signal?: AbortSignal;
}): Promise<SpritePlayer>;
