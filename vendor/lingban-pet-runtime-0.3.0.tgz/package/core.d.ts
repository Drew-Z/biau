export type Point = {x: number; y: number};
export type Motion = {
  version: 1; sourceFrameCount: number; entries: {sourceFrame: number; durationMs: number}[]; loop: boolean;
  registration: "preserve" | "body" | "support";
  anchors: {sourceFrame: number; body: Point; support?: Point}[]; contacts: number[];
  root: (Point & {entryIndex: number})[];
};
export type Drawable = {id?: string; kind?: string; url?: string; sha256?: string; meta: {
  frameCount: number; frameWidth: number; frameHeight: number; fps?: number; loop?: boolean;
  motion?: Motion; motionReview?: {anchors: string};
  processing?: {frameOrder?: number[]; transforms?: {scale: number; x: number; y: number}[]};
}};
export type Activity = "idle" | "thinking" | "working" | "needsInput" | "review" | "ready" | "blocked" | "sleepy";
export type CoreActionId = "idle" | "happy" | "sleepy";
export type ActionId = CoreActionId | "thinking" | "working" | "waiting" | "review" | "failed";
type PublicAction = Drawable & {file: string; sha256: string};
export type PublicPet = {representation: "sprite2d"; name: string; license: {status: "not-specified"}} & (
  {schemaVersion: 1; actions: Record<CoreActionId, PublicAction>} |
  {schemaVersion: 2; actionSet: "assistant-v1"; actions: Record<ActionId, PublicAction>}
);
export const CORE_ACTIONS: readonly CoreActionId[];
export const ASSISTANT_ACTIONS: readonly ActionId[];
export function playbackEntries(asset: Drawable): {sourceFrame: number; durationMs: number}[];
export function actionDurationMs(asset: Drawable): number;
export function frameOffset(asset: Drawable, entryIndex: number): Point;
export function displayedAnchor(asset: Drawable, entryIndex: number, kind: "body" | "support"): Point | null;
export function playbackAt(asset: Drawable, elapsedMs: number, loopOverride?: boolean): {entryIndex: number; sourceFrame: number; logicalSourceFrame: number; completed: boolean};
export function validateDrawable(value: unknown): Drawable;
export function validatePet(value: unknown): PublicPet;
export function loadPet(url: string, signal?: AbortSignal): Promise<PublicPet>;
export function readBytes(url: string, maxBytes: number, signal?: AbortSignal): Promise<Uint8Array>;
export function chooseAction(activity: Activity, availableActions?: readonly ActionId[]): ActionId;
export function createController(onChange: (action: ActionId, once: boolean) => void, availableActions?: readonly ActionId[]): {
  setActivity(activity: Activity): void; greet(): void; complete(): void; destroy(): void;
};
